Model made by Thunder
You may do whatever you want with this model, skin it,make it better or whatever.
Just 2 things I dont want:
-Not allow to sell this model
-dont claim it as yours

have fun with it.

Use the blitzwheels for wheels, the model is tagged like the blitz with both wheel_tags and both objective_tag

greetz Thunder