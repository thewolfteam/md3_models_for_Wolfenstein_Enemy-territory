Different versions for the buddha model
(all of them are placed in the models/mapobjects/buddha directory)

buddha.md3	a stone buddha, default shader (simple texture)
buddha_g.md3	a gold buddha, shader with environment map
buddha_j.md3	a jade buddha, shader with environment map
buddha_m.md3	a magic buddha, two-pass shader with special effects
buddha_f.md3	a false buddha, two-passes plus lightmap