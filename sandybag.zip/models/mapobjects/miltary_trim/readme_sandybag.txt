Author:thunder

lisence: Creative Commons Zero v1.0 Universal

program for modelling:
milkshape3d

uvtool:
lithunwrap

resources used for sandbag texture:
http://mb3d.co.uk/mb3d/Fabric_Seamless_and_Tileable_High_Res_Textures_files/Hassien_01_UV_H_CM_1.jpg
http://mb3d.co.uk/mb3d/Fabric_Seamless_and_Tileable_High_Res_Textures_files/Cloth_Crinkled_Cotton_Ironed_1.jpg