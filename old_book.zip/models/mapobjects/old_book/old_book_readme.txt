Old book.

Originally created for DungeonHack.

Created in Blender 2.49b.

48 faces

92 triangle faces

512x512 textures

rescaled and made md3 by Thunder