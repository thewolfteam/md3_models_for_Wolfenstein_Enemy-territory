goldbars md3 models for use with wolfET

made by thunder!

have a ball!!

paste into etmain to use!

